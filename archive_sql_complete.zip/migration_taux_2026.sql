-- ============================================================
-- TAUX 2026 — Valorisation horaire (SMIC) + Indemnité kilométrique
-- ============================================================

-- ---- Valorisation horaire par catégorie ----
insert into taux_valorisation (annee, type_activite, taux_horaire) values
  (2026, 'direction', 89.10),   -- 5 x SMIC x 1,5
  (2026, 'cadre',     53.46),   -- 3 x SMIC x 1,5
  (2026, 'agent',     21.384),  -- 1,2 x SMIC x 1,5
  (2026, 'autre',     11.88);   -- SMIC de base — À CONFIRMER, valeur provisoire

-- ============================================================
-- Indemnité kilométrique (par année, indépendante de la catégorie)
-- ============================================================
create table taux_kilometrique (
  annee smallint primary key,
  taux_par_km numeric(6,3) not null
);

insert into taux_kilometrique (annee, taux_par_km) values
  (2026, 0.606);

-- ============================================================
-- Mise à jour de bilan_benevole_annuel : ajout du montant IK
-- ============================================================
drop function if exists bilan_benevole_annuel(uuid, smallint);

create or replace function bilan_benevole_annuel(p_benevole_id uuid, p_annee smallint)
returns table (
  nb_jours_presence bigint,
  total_heures numeric,
  nb_jours_conge bigint,
  distance_totale_km numeric,
  montant_indemnite_km numeric
) as $$
  select
    count(distinct p.date) filter (where p.type = 'presence') as nb_jours_presence,
    round(coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0)
      filter (where p.type = 'presence'), 0)::numeric, 2) as total_heures,
    count(distinct p.date) filter (where p.type = 'conge') as nb_jours_conge,
    round((count(distinct p.date) filter (where p.type = 'presence')
      * coalesce((select distance_km from benevoles where id = p_benevole_id), 0))::numeric, 1) as distance_totale_km,
    round((count(distinct p.date) filter (where p.type = 'presence')
      * coalesce((select distance_km from benevoles where id = p_benevole_id), 0)
      * coalesce((select taux_par_km from taux_kilometrique where annee = p_annee), 0))::numeric, 2) as montant_indemnite_km
  from pointages p
  where p.benevole_id = p_benevole_id
    and extract(year from p.date) = p_annee;
$$ language sql stable;

-- ============================================================
-- Mise à jour de bilan_association_annuel : ajout du total IK
-- (toutes catégories confondues, la distance ne dépend pas du type_activite)
-- ============================================================
drop function if exists bilan_association_annuel(smallint);

create or replace function bilan_association_annuel(p_annee smallint)
returns table (
  type_activite type_activite,
  nb_benevoles bigint,
  total_heures numeric,
  taux_horaire numeric,
  cout_valorise_heures numeric
) as $$
  select
    b.type_activite,
    count(distinct b.id) as nb_benevoles,
    round(coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0), 0)::numeric, 2) as total_heures,
    tv.taux_horaire,
    round((coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0), 0)
      * coalesce(tv.taux_horaire, 0))::numeric, 2) as cout_valorise_heures
  from benevoles b
  left join pointages p on p.benevole_id = b.id
    and p.type = 'presence'
    and extract(year from p.date) = p_annee
  left join taux_valorisation tv on tv.annee = p_annee and tv.type_activite = b.type_activite
  where b.type_activite is not null
  group by b.type_activite, tv.taux_horaire;
$$ language sql stable;

-- Total des indemnités kilométriques de l'année, toutes catégories confondues
create or replace function total_indemnites_km_annuel(p_annee smallint)
returns numeric as $$
  select round(coalesce(sum(
    (select montant_indemnite_km from bilan_benevole_annuel(b.id, p_annee))
  ), 0)::numeric, 2)
  from benevoles b;
$$ language sql stable;
