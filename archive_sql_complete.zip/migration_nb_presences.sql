-- ============================================================
-- MIGRATION — Compteur de présences (nb_presences)
-- ============================================================

-- 1. Nouvelle colonne sur benevoles
alter table benevoles add column nb_presences integer not null default 0;

-- 2. Incrémentation automatique : une fois par JOUR de présence (pas par créneau)
--    Un bénévole qui pointe deux fois le même jour (collecte) ne compte que pour 1.
create or replace function incrementer_nb_presences()
returns trigger as $$
begin
  if new.type = 'presence' then
    if not exists (
      select 1 from pointages
      where benevole_id = new.benevole_id
        and date = new.date
        and type = 'presence'
        and id <> new.id
    ) then
      update benevoles set nb_presences = nb_presences + 1 where id = new.benevole_id;
    end if;
  end if;
  return new;
end;
$$ language plpgsql;

create trigger trg_increment_presence
after insert on pointages
for each row execute function incrementer_nb_presences();

-- 3. Décrémentation : seulement si c'était le dernier pointage du bénévole ce jour-là
create or replace function decrementer_nb_presences()
returns trigger as $$
begin
  if old.type = 'presence' then
    if not exists (
      select 1 from pointages
      where benevole_id = old.benevole_id
        and date = old.date
        and type = 'presence'
        and id <> old.id
    ) then
      update benevoles set nb_presences = greatest(0, nb_presences - 1) where id = old.benevole_id;
    end if;
  end if;
  return old;
end;
$$ language plpgsql;

create trigger trg_decrement_presence
after delete on pointages
for each row execute function decrementer_nb_presences();

-- 4. Rattrapage : compte les JOURS distincts de présence déjà existants
update benevoles b
set nb_presences = coalesce(
  (select count(distinct date) from pointages p where p.benevole_id = b.id and p.type = 'presence'),
  0
);
