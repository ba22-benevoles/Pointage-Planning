-- ============================================================
-- MIGRATION — Auto-gestion des congés par le bénévole
-- (voir ses propres déclarations à venir, et les annuler)
-- ============================================================

-- Fonction sécurisée : ne supprime QUE si numero + nom correspondent
-- bien au propriétaire du congé. SECURITY DEFINER = s'exécute avec les
-- droits du créateur de la fonction, pas ceux de l'appelant anonyme,
-- ce qui permet de contourner RLS de façon contrôlée (uniquement via
-- cette vérification précise, pas d'accès direct à la table).
create or replace function annuler_conge(p_conge_id uuid, p_numero smallint, p_nom text)
returns boolean as $$
declare
  deleted_count int;
begin
  delete from conges c
  using benevoles b
  where c.id = p_conge_id
    and c.benevole_id = b.id
    and b.numero = p_numero
    and b.nom ilike p_nom;

  get diagnostics deleted_count = row_count;
  return deleted_count > 0;
end;
$$ language plpgsql security definer;

-- Autorise le rôle public (anon, utilisé par le kiosque) à appeler cette fonction
grant execute on function annuler_conge(uuid, smallint, text) to anon;
