-- ============================================================
-- MIGRATION — Ajout du poste "Salarié" (3 personnes fixes, tous les jours)
-- ============================================================

insert into postes (id, nom, effectif_min, effectif_max) values
  (9, 'Salarié', 3, 3);
