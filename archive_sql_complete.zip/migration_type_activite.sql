-- ============================================================
-- MIGRATION — Type d'activité (pour valorisation du coût bénévole)
-- ============================================================

create type type_activite as enum ('direction', 'cadre', 'agent', 'autre');

alter table benevoles add column type_activite type_activite;
