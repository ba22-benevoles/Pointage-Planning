-- ============================================================
-- MIGRATION — Bilans annuels (CERFA bénévole + coût association)
-- ============================================================

-- ============================================================
-- 1. TAUX DE VALORISATION (SMIC selon catégorie, par année)
--    À compléter chaque année avec le SMIC en vigueur.
-- ============================================================
create table taux_valorisation (
  annee smallint not null,
  type_activite type_activite not null,
  taux_horaire numeric(6,2) not null,
  primary key (annee, type_activite)
);

-- Exemple à adapter avec les vrais montants retenus par l'association :
-- insert into taux_valorisation (annee, type_activite, taux_horaire) values
--   (2026, 'direction', 25.00),
--   (2026, 'cadre',     20.00),
--   (2026, 'agent',     11.88),  -- SMIC horaire brut 2026 à vérifier/ajuster
--   (2026, 'autre',     11.88);

-- ============================================================
-- 2. DURÉE D'UN POINTAGE (avec la règle des 3h par défaut)
--    Un pointage sans heure_depart (oubli) compte forfaitairement
--    pour 180 minutes plutôt que 0.
-- ============================================================
create or replace function duree_pointage(p_heure_arrivee time, p_heure_depart time)
returns interval as $$
begin
  if p_heure_depart is null or p_heure_arrivee is null then
    return interval '180 minutes';
  end if;
  return p_heure_depart - p_heure_arrivee;
end;
$$ language plpgsql immutable;

-- ============================================================
-- 3. BILAN ANNUEL PAR BÉNÉVOLE (pour le CERFA)
--    Filtré par année directement sur pointages.date : aucune
--    remise à zéro nécessaire, chaque année démarre naturellement
--    à zéro puisqu'aucun pointage n'y existe encore.
-- ============================================================
create or replace function bilan_benevole_annuel(p_benevole_id uuid, p_annee smallint)
returns table (
  nb_jours_presence bigint,
  total_heures numeric,
  nb_jours_conge bigint,
  distance_totale_km numeric
) as $$
  select
    count(distinct p.date) filter (where p.type = 'presence') as nb_jours_presence,
    round(coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0)
      filter (where p.type = 'presence'), 0)::numeric, 2) as total_heures,
    count(distinct p.date) filter (where p.type = 'conge') as nb_jours_conge,
    round((count(distinct p.date) filter (where p.type = 'presence')
      * coalesce((select distance_km from benevoles where id = p_benevole_id), 0))::numeric, 1) as distance_totale_km
  from pointages p
  where p.benevole_id = p_benevole_id
    and extract(year from p.date) = p_annee;
$$ language sql stable;

-- ============================================================
-- 4. BILAN ANNUEL GLOBAL DE L'ASSOCIATION (coût total valorisé)
-- ============================================================
create or replace function bilan_association_annuel(p_annee smallint)
returns table (
  type_activite type_activite,
  nb_benevoles bigint,
  total_heures numeric,
  taux_horaire numeric,
  cout_valorise numeric
) as $$
  select
    b.type_activite,
    count(distinct b.id) as nb_benevoles,
    round(coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0), 0)::numeric, 2) as total_heures,
    tv.taux_horaire,
    round((coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0), 0)
      * coalesce(tv.taux_horaire, 0))::numeric, 2) as cout_valorise
  from benevoles b
  left join pointages p on p.benevole_id = b.id
    and p.type = 'presence'
    and extract(year from p.date) = p_annee
  left join taux_valorisation tv on tv.annee = p_annee and tv.type_activite = b.type_activite
  where b.type_activite is not null
  group by b.type_activite, tv.taux_horaire;
$$ language sql stable;
