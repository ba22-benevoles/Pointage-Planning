-- ============================================================
-- MIGRATION — Verrou d'entrée du site, vérifié côté serveur
-- ============================================================

-- Extension nécessaire pour le hachage (crypt / gen_salt)
create extension if not exists pgcrypto;

-- Table de stockage du mot de passe haché (jamais en clair)
create table site_secrets (
  cle text primary key,
  valeur_hash text not null
);

-- RLS activée, AUCUNE policy = personne (anon compris) ne peut lire
-- cette table directement, même pas via l'API Supabase.
alter table site_secrets enable row level security;

-- Insère le mot de passe (à remplacer par le tien avant exécution) — haché immédiatement
insert into site_secrets (cle, valeur_hash)
values ('mot_de_passe_site', crypt('CHANGE_MOI', gen_salt('bf')));

-- ============================================================
-- POUR CHANGER LE MOT DE PASSE PLUS TARD, relance simplement :
--
-- update site_secrets
-- set valeur_hash = crypt('NOUVEAU_MOT_DE_PASSE', gen_salt('bf'))
-- where cle = 'mot_de_passe_site';
--
-- Aucune autre modification nécessaire (ni dans le code, ni ailleurs).
-- ============================================================

-- Fonction de vérification : reçoit le mot de passe en clair depuis le
-- client, le compare au hash stocké, ne renvoie qu'un booléen.
-- SECURITY DEFINER = s'exécute avec des droits élevés, peut donc lire
-- site_secrets malgré la RLS qui bloque tout accès direct.
create or replace function verifier_mdp_site(p_mdp text)
returns boolean as $$
declare
  stored text;
begin
  select valeur_hash into stored from site_secrets where cle = 'mot_de_passe_site';
  if stored is null then return false; end if;
  return stored = crypt(p_mdp, stored);
end;
$$ language plpgsql security definer;

grant execute on function verifier_mdp_site(text) to anon;
