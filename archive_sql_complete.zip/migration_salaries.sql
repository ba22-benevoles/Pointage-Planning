-- ============================================================
-- MIGRATION — Distinction bénévole / salarié
-- ============================================================

create type categorie_personne as enum ('benevole', 'salarie');

-- Défaut 'benevole' : les 99 fiches existantes restent inchangées
alter table benevoles add column categorie categorie_personne not null default 'benevole';

-- ============================================================
-- Exclusion des salariés des bilans de valorisation (SMIC + IK)
-- Le pointage, le planning et les congés restent, eux, identiques
-- pour tout le monde — seuls les calculs de coût bénévolat changent.
-- ============================================================

drop function if exists bilan_association_annuel(smallint);

create or replace function bilan_association_annuel(p_annee smallint)
returns table (
  type_activite type_activite,
  nb_benevoles bigint,
  total_heures numeric,
  taux_horaire numeric,
  cout_valorise_heures numeric
) as $$
begin
  if not exists (select 1 from admins where user_id = auth.uid()) then
    raise exception 'Accès réservé aux administrateurs';
  end if;

  return query
  select
    b.type_activite,
    count(distinct b.id) as nb_benevoles,
    round(coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0), 0)::numeric, 2) as total_heures,
    tv.taux_horaire,
    round((coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0), 0)
      * coalesce(tv.taux_horaire, 0))::numeric, 2) as cout_valorise_heures
  from benevoles b
  left join pointages p on p.benevole_id = b.id
    and p.type = 'presence'
    and extract(year from p.date) = p_annee
  left join taux_valorisation tv on tv.annee = p_annee and tv.type_activite = b.type_activite
  where b.type_activite is not null
    and b.categorie = 'benevole'
  group by b.type_activite, tv.taux_horaire;
end;
$$ language plpgsql stable security definer;

drop function if exists total_indemnites_km_annuel(smallint);

create or replace function total_indemnites_km_annuel(p_annee smallint)
returns numeric as $$
begin
  if not exists (select 1 from admins where user_id = auth.uid()) then
    raise exception 'Accès réservé aux administrateurs';
  end if;

  return (
    select round(coalesce(sum(
      count_presence.nb * coalesce(b.distance_km, 0) * coalesce(tk.taux_par_km, 0)
    ), 0)::numeric, 2)
    from benevoles b
    left join taux_kilometrique tk on tk.annee = p_annee
    left join lateral (
      select count(distinct p.date) as nb
      from pointages p
      where p.benevole_id = b.id and p.type = 'presence' and extract(year from p.date) = p_annee
    ) count_presence on true
    where b.categorie = 'benevole'
  );
end;
$$ language plpgsql stable security definer;

drop function if exists bilan_tous_benevoles_annuel(smallint);

create or replace function bilan_tous_benevoles_annuel(p_annee smallint)
returns table (
  benevole_id uuid,
  numero smallint,
  nom text,
  prenom text,
  nb_jours_presence bigint,
  total_heures numeric,
  nb_jours_conge bigint,
  distance_totale_km numeric,
  montant_indemnite_km numeric
) as $$
begin
  if not exists (select 1 from admins where user_id = auth.uid()) then
    raise exception 'Accès réservé aux administrateurs';
  end if;

  return query
  select
    b.id,
    b.numero,
    b.nom,
    b.prenom,
    count(distinct p.date) filter (where p.type = 'presence') as nb_jours_presence,
    round(coalesce(sum(extract(epoch from duree_pointage(p.heure_arrivee, p.heure_depart)) / 3600.0)
      filter (where p.type = 'presence'), 0)::numeric, 2) as total_heures,
    count(distinct p.date) filter (where p.type = 'conge') as nb_jours_conge,
    round((count(distinct p.date) filter (where p.type = 'presence') * coalesce(b.distance_km, 0))::numeric, 1) as distance_totale_km,
    round((count(distinct p.date) filter (where p.type = 'presence') * coalesce(b.distance_km, 0)
      * coalesce((select tk.taux_par_km from taux_kilometrique tk where tk.annee = p_annee), 0))::numeric, 2) as montant_indemnite_km
  from benevoles b
  left join pointages p on p.benevole_id = b.id and extract(year from p.date) = p_annee
  where b.categorie = 'benevole'
  group by b.id, b.numero, b.nom, b.prenom
  order by b.nom;
end;
$$ language plpgsql stable security definer;
