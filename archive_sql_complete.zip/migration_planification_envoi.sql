-- ============================================================
-- MIGRATION — Planification de l'envoi automatique du planning
-- (à exécuter APRÈS avoir déployé l'Edge Function envoyer-planning-hebdo)
-- ============================================================

-- pg_net permet à Postgres de faire des appels HTTP sortants
-- (nécessaire pour déclencher l'Edge Function depuis pg_cron)
create extension if not exists pg_net;

-- ⚠️ Remplace les deux valeurs ci-dessous avant d'exécuter :
--   - TON_PROJET : l'identifiant de ton projet Supabase (visible dans l'URL du dashboard)
--   - TA_SERVICE_ROLE_KEY : Project Settings → API → service_role key (secrète, jamais dans le front-end)
select cron.schedule(
  'envoi-planning-hebdo',
  '0 7 * * 5',  -- chaque vendredi à 7h UTC (≈ 8h ou 9h en France selon l'heure d'été/hiver)
  $$
  select net.http_post(
    url := 'https://TON_PROJET.supabase.co/functions/v1/envoyer-planning-hebdo',
    headers := jsonb_build_object(
      'Authorization', 'Bearer TA_SERVICE_ROLE_KEY',
      'Content-Type', 'application/json'
    ),
    body := '{}'::jsonb
  );
  $$
);

-- Pour vérifier que la tâche est bien programmée :
-- select * from cron.job where jobname = 'envoi-planning-hebdo';

-- Pour la supprimer si besoin de la reconfigurer :
-- select cron.unschedule('envoi-planning-hebdo');
