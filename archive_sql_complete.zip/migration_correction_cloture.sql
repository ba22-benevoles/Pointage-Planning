-- ============================================================
-- MIGRATION — Correction de la policy de clôture de pointage
--
-- Sans clause WITH CHECK explicite, Postgres réutilise la
-- condition USING pour vérifier aussi la ligne APRÈS modification.
-- Or on veut justement que heure_depart passe de null à une heure
-- précise — la policy se bloquait donc elle-même.
-- ============================================================

drop policy "kiosque peut cloturer son pointage" on pointages;

create policy "kiosque peut cloturer son pointage"
  on pointages for update
  using (heure_depart is null)   -- la ligne ciblée doit être une session ouverte
  with check (true);              -- mais le résultat après modif n'a pas à l'être
