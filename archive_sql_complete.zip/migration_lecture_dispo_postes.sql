-- ============================================================
-- MIGRATION — Policies de lecture manquantes
-- Sans elles, le kiosque (non connecté) ne peut voir ni les jours
-- habituels ni les postes qualifiés des bénévoles — d'où la liste
-- "attendus aujourd'hui" vide malgré des données bien présentes.
-- ============================================================

create policy "lecture des disponibilites"
  on disponibilites for select
  using (true);

create policy "lecture des qualifications"
  on benevole_postes for select
  using (true);
