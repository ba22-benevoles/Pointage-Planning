-- ============================================================
-- MIGRATION — Policy de lecture manquante sur pointages
-- Sans elle, le kiosque ne peut jamais relire un pointage déjà
-- enregistré (arrivée ou départ), même si la donnée existe bien.
-- ============================================================

create policy "lecture des pointages"
  on pointages for select
  using (true);
