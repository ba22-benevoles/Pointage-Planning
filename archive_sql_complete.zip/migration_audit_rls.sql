-- ============================================================
-- MIGRATION — Correctif audit RLS : taux_valorisation et
-- taux_kilometrique n'avaient AUCUNE protection (RLS jamais activée).
-- N'importe qui pouvait lire ET modifier ces taux sans être admin.
-- ============================================================

alter table taux_valorisation enable row level security;
alter table taux_kilometrique enable row level security;

create policy "admin gere les taux de valorisation"
  on taux_valorisation for all
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin gere le taux kilometrique"
  on taux_kilometrique for all
  using (exists (select 1 from admins where user_id = auth.uid()));

-- ============================================================
-- Bonus (prévention) : la table postes a bien une lecture publique,
-- mais aucune policy d'écriture pour l'admin. Pas utilisé aujourd'hui
-- (les 8 postes sont fixes), mais ajouté au cas où une gestion des
-- postes serait ajoutée un jour à l'admin.
-- ============================================================
create policy "admin gere les postes"
  on postes for all
  using (exists (select 1 from admins where user_id = auth.uid()));
