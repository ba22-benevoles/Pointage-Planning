-- ============================================================
-- SCHEMA — Pointage / Planning BA22
-- A exécuter dans Supabase (SQL Editor), dans l'ordre.
-- ============================================================

-- ============================================================
-- 1. BÉNÉVOLES
-- ============================================================
create type benevole_statut as enum ('actif', 'longue_absence', 'conges', 'inactif');

create table benevoles (
  id uuid primary key default gen_random_uuid(),
  numero smallint not null unique,   -- numéro à 3 chiffres, ancien système de pointage
  nom text not null,
  prenom text not null,
  statut benevole_statut not null default 'actif',
  distance_km numeric(5,1),          -- aller-retour domicile <-> BA, pour frais de route
  rue text,
  code_postal text,
  ville text,
  email text,
  telephone text,
  created_at timestamptz not null default now()
);

alter table benevoles add constraint chk_numero_3_chiffres
  check (numero between 0 and 999);

create index idx_benevoles_statut on benevoles(statut);
create index idx_benevoles_numero on benevoles(numero);

-- ============================================================
-- 2. POINTAGES
-- ============================================================
create type pointage_type as enum ('presence', 'conge', 'absence');

create table pointages (
  id uuid primary key default gen_random_uuid(),
  benevole_id uuid not null references benevoles(id) on delete cascade,
  date date not null,
  heure_arrivee time,               -- NULL si congé/absence
  heure_depart time,                -- NULL si session encore ouverte
  type pointage_type not null default 'presence',
  created_at timestamptz not null default now()
);

-- Une seule session ouverte à la fois par bénévole
create unique index idx_pointage_ouvert
  on pointages(benevole_id)
  where heure_depart is null and type = 'presence';

create index idx_pointages_benevole_date on pointages(benevole_id, date);

-- ============================================================
-- 3. POSTES (les 8 postes fixes, avec capacités)
-- ============================================================
create table postes (
  id smallint primary key,
  nom text not null unique,
  effectif_min smallint not null default 0,
  effectif_max smallint    -- NULL = pas de limite fixe
);

insert into postes (id, nom, effectif_min, effectif_max) values
  (1, 'Tri Fruits & Légumes', 0, 7),
  (2, 'Frais',                0, 3),
  (3, 'Chauffeur',            7, 9),
  (4, 'Bureau',               0, null),
  (5, 'Préparation',          2, 3),
  (6, 'Hygiène',              2, 2),
  (7, 'Cuisine',              1, 2),
  (8, 'Partenariat',          2, 3);

-- ============================================================
-- 4. QUALIFICATIONS (many-to-many bénévoles <-> postes)
-- ============================================================
create table benevole_postes (
  benevole_id uuid not null references benevoles(id) on delete cascade,
  poste_id smallint not null references postes(id) on delete restrict,
  primary key (benevole_id, poste_id)
);

-- ============================================================
-- 5. DISPONIBILITÉS (rythme habituel récurrent, Lun=1 ... Sam=6)
-- ============================================================
create table disponibilites (
  benevole_id uuid not null references benevoles(id) on delete cascade,
  jour_semaine smallint not null,
  primary key (benevole_id, jour_semaine),
  constraint chk_jour check (jour_semaine between 1 and 6)
);

-- ============================================================
-- 6. CONGÉS / ABSENCES PONCTUELS (période, saisi par admin ou bénévole)
-- ============================================================
create type conge_origine as enum ('admin', 'benevole');

create table conges (
  id uuid primary key default gen_random_uuid(),
  benevole_id uuid not null references benevoles(id) on delete cascade,
  debut date not null,
  fin date not null,
  type pointage_type not null default 'conge',   -- 'conge' ou 'absence'
  origine conge_origine not null default 'admin',
  created_at timestamptz not null default now(),
  constraint chk_periode check (fin >= debut)
);

create index idx_conges_benevole on conges(benevole_id);
create index idx_conges_periode on conges(debut, fin);

-- ============================================================
-- 7. PLANNING (une fois une proposition validée par l'admin)
-- ============================================================
create table planning (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  poste_id smallint not null references postes(id),
  benevole_id uuid not null references benevoles(id) on delete cascade,
  valide boolean not null default false,
  created_at timestamptz not null default now(),
  unique (date, benevole_id)   -- un bénévole = un seul poste par jour
);

-- ============================================================
-- 8. ADMINS (qui a accès à l'espace admin)
-- ============================================================
create table admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

-- ============================================================
-- 9. RLS
-- ============================================================
alter table benevoles enable row level security;
alter table pointages enable row level security;
alter table postes enable row level security;
alter table benevole_postes enable row level security;
alter table disponibilites enable row level security;
alter table conges enable row level security;
alter table planning enable row level security;

-- --- Postes : liste fixe, lecture large (utile partout, kiosque compris) ---
create policy "lecture publique des postes"
  on postes for select
  using (true);

-- --- Bénévoles : le kiosque doit voir les noms actifs pour pointer ---
create policy "kiosque lit les benevoles actifs"
  on benevoles for select
  using (statut = 'actif');

-- --- Pointages : le kiosque peut créer et clôturer ses propres sessions ---
create policy "kiosque peut pointer"
  on pointages for insert
  with check (true);

create policy "kiosque peut cloturer son pointage"
  on pointages for update
  using (heure_depart is null);

-- --- Congés : insertion ouverte (auto-déclaration + admin), lecture ouverte pour affichage kiosque/admin ---
create policy "lecture des conges"
  on conges for select
  using (true);

create policy "insertion des conges"
  on conges for insert
  with check (true);

-- --- Admin : accès total sur tout, via la table admins ---
create policy "admin acces total benevoles"
  on benevoles for all
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin acces total pointages"
  on pointages for all
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin gere les qualifications"
  on benevole_postes for all
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin gere les disponibilites"
  on disponibilites for all
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin gere les conges"
  on conges for update
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin supprime les conges"
  on conges for delete
  using (exists (select 1 from admins where user_id = auth.uid()));

create policy "admin gere le planning"
  on planning for all
  using (exists (select 1 from admins where user_id = auth.uid()));
