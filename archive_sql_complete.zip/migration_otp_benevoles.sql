-- ============================================================
-- MIGRATION — Authentification bénévole par email (OTP Supabase)
-- ============================================================

-- Lien entre une fiche bénévole et son compte d'authentification
alter table benevoles add column auth_user_id uuid references auth.users(id);
create unique index idx_benevoles_auth_user on benevoles(auth_user_id) where auth_user_id is not null;

-- ============================================================
-- Fonction appelée juste après une connexion OTP réussie :
-- relie automatiquement le compte auth au bénévole ayant le même email.
-- SECURITY DEFINER : nécessaire pour pouvoir modifier benevoles malgré la RLS,
-- mais la logique interne ne relie QUE le compte de l'appelant à SA PROPRE fiche.
-- ============================================================
create or replace function lier_mon_compte()
returns boolean as $$
declare
  mon_email text;
  matched_id uuid;
begin
  select email into mon_email from auth.users where id = auth.uid();
  if mon_email is null then return false; end if;

  select id into matched_id from benevoles
  where lower(trim(email)) = lower(trim(mon_email))
  limit 1;

  if matched_id is null then return false; end if;

  update benevoles set auth_user_id = auth.uid()
  where id = matched_id and auth_user_id is null;

  return true;
end;
$$ language plpgsql security definer;

grant execute on function lier_mon_compte() to authenticated;

-- ============================================================
-- RLS conges : on retire l'insertion totalement publique, on la
-- remplace par deux règles précises (admin, ou bénévole pour lui-même)
-- ============================================================
drop policy "insertion des conges" on conges;

create policy "admin insere des conges"
  on conges for insert
  with check (exists (select 1 from admins where user_id = auth.uid()));

create policy "benevole insere ses propres conges"
  on conges for insert
  with check (benevole_id in (select id from benevoles where auth_user_id = auth.uid()));

create policy "benevole supprime ses propres conges"
  on conges for delete
  using (benevole_id in (select id from benevoles where auth_user_id = auth.uid()));
