-- Resserre la contrainte du numéro de badge à 100-999 (toujours 3 chiffres),
-- cohérent avec l'ancien système physique.
alter table benevoles drop constraint chk_numero_3_chiffres;
alter table benevoles add constraint chk_numero_3_chiffres check (numero between 100 and 999);
