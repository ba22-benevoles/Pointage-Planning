-- ============================================================
-- MIGRATION — Départs de bénévoles + anonymisation automatique (RGPD)
-- ============================================================

-- Date à laquelle le bénévole a quitté l'association
alter table benevoles add column date_depart date;

-- ============================================================
-- Fonction d'anonymisation : supprime les données identifiantes
-- des bénévoles partis, 2 mois après la fin de l'année de leur
-- départ (le temps de préparer et transmettre leur CERFA sans
-- être pris de court début janvier). Les données chiffrées
-- (heures, présences) restent conservées pour ne pas fausser
-- l'historique des bilans passés.
--
-- Principe RGPD de minimisation : on ne garde les données
-- identifiantes que le temps nécessaire à la finalité (ici, la
-- préparation du CERFA de l'année du départ) — pas plus.
-- ============================================================
create or replace function anonymiser_departs_expires()
returns void as $$
begin
  update benevoles
  set
    nom = 'Anonymisé',
    prenom = '',
    email = null,
    telephone = null,
    rue = null,
    code_postal = null,
    ville = null,
    auth_user_id = null
  where date_depart is not null
    -- Seuil = 1er janvier de l'année suivant le départ + 2 mois de marge (donc 1er mars)
    and current_date >= date_trunc('year', date_depart) + interval '1 year 2 months'
    and nom <> 'Anonymisé'; -- déjà traité, ne pas repasser dessus
end;
$$ language plpgsql;

-- ============================================================
-- Planification automatique (comme handle_rights_lifecycle sur ESL22)
-- Vérifie une fois par mois, largement suffisant vu la volumétrie.
-- ============================================================
select cron.schedule(
  'anonymisation-departs-rgpd',
  '0 3 1 * *',  -- le 1er de chaque mois à 3h du matin
  $$ select anonymiser_departs_expires(); $$
);
