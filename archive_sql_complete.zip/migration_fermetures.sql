-- ============================================================
-- MIGRATION — Fermetures de la BA (période entière, tout le monde)
-- ============================================================

create table fermetures (
  id uuid primary key default gen_random_uuid(),
  debut date not null,
  fin date not null,
  motif text,
  created_at timestamptz not null default now(),
  constraint chk_periode_fermeture check (fin >= debut)
);

alter table fermetures enable row level security;

-- Lecture publique : le kiosque doit savoir si la BA est fermée aujourd'hui
create policy "lecture publique des fermetures"
  on fermetures for select
  using (true);

create policy "admin gere les fermetures"
  on fermetures for all
  using (exists (select 1 from admins where user_id = auth.uid()));
